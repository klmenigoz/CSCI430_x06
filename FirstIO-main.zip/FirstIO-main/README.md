[![C++ CI](https://github.com/ChicoState/FirstIO/actions/workflows/actions.yml/badge.svg)](https://github.com/ChicoState/FirstIO/actions/workflows/actions.yml)

# First IO project